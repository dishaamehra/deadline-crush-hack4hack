# Deadline Crush test fixture

A small valid project archive for upload and recovery tests.
